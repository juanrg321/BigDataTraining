import json
import boto3
import base64

# Initialize the DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('vehicleStateTemps')

def lambda_handler(event, context):
    for record in event['Records']:
        # Decode the Kinesis record data
        data = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        payload = json.loads(data)
        
        # Extract the state, average temperature, and average rainfall
        state = payload['state']
        avg_temp = payload['average_temperature']
        avg_rainfall = payload['average_rainfall']
        state_lower = state.lower()
        # Write the data to DynamoDB
        try:
            response = table.put_item(
                Item={
                    'state': state_lower,
                    'average_temperature': avg_temp,
                    'average_rainfall': avg_rainfall
                }
            )
            print(f"Successfully wrote to DynamoDB: {response}")
        except Exception as e:
            print(f"Error writing to DynamoDB: {e}")

    return {
        'statusCode': 200,
        'body': json.dumps('Data processed successfully!')
    }
