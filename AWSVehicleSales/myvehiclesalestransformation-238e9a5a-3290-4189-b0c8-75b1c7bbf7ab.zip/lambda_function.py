import boto3
import pandas as pd
import io
from datetime import datetime
from io import StringIO
# Initialize the S3 client

s3_client = boto3.client('s3')
# Function to read data from S3 bucket
def read_from_s3(bucket_name, key):
    response = s3_client.get_object(Bucket=bucket_name, Key=key)
    data = response['Body'].read()
    return pd.read_csv(io.BytesIO(data))

# Function to write DataFrame to S3
def write_to_s3(df, bucket_name, key):

    parquet_buffer = io.BytesIO()  # Use BytesIO for binary data
    df.to_parquet(parquet_buffer, index=False)

    s3_client.put_object(Bucket=bucket_name, Key=key, Body=parquet_buffer.getvalue())

# Function to clean the DataFrame
def clean_data(df):
    # Check for null values and remove rows with any nulls
    df = df.dropna()

    # Remove duplicates
    df = df.drop_duplicates()

    # Remove rows with negative values
    numeric_cols = df.select_dtypes(include='number').columns
    df = df[(df[numeric_cols] >= 0).all(axis=1)]

    # Remove rows where all values are hyphens (special character '–', U+2013)
    df = df[~df.apply(lambda row: row.astype(str).str.contains('–').all(), axis=1)]

    # Convert everything except 'saledate' column to lowercase
    for col in df.columns:
        if col != 'saledate':
            df[col] = df[col].astype(str).str.lower()
    
    # Check for non-numeric entries in numerical columns
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    for col in numeric_cols:
        df[col] = df[col].replace(r'\D', '', regex=True).astype(float)
    
    pd.set_option('display.max_colwidth', None)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.width', 1000)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.colheader_justify', 'left')
    pd.options.display.float_format = '{:.0f}'.format
    
    df['saledate'] = df['saledate'].str.split('GMT').str[0].str.strip()
    df['saledate'] = pd.to_datetime(df['saledate'], format='%a %b %d %Y %H:%M:%S')
    df['saledate'] = df['saledate'].dt.strftime('%Y-%m-%d %H:%M:%S')
    
    # Explicitly convert saledate to string to ensure proper CSV output
    df['saledate'] = df['saledate'].astype(str)

    for col in numeric_cols:
        # Strip whitespace and convert to numeric type, coercing errors to NaN
        df[col] = pd.to_numeric(df[col].astype(str).str.strip(), errors='coerce')

    df = df.dropna(axis=1, how='any')
    df['year'] = df['year'].astype(int)
    df['odometer'] = df['odometer'].astype(int)

    # Drop the 'created_at' column if it exists
    if 'created_at' in df.columns:
        df = df.drop(columns=['created_at'])

    return df

def lambda_handler(event, context):
    bucket_name = 'myvehiclesalesproject'
    raw_key = 'rawbronze/toprocess/data.csv'
    processed_key = 'stagingsilver/cleaned_vehicle_sales' + str(datetime.now()) + '.parquet'

    # Load data from S3
    df = read_from_s3(bucket_name, raw_key)
    
    # Clean data
    df_cleaned = clean_data(df)

    # Write cleaned data back to S3 in 'processed' folder
    write_to_s3(df_cleaned, bucket_name, processed_key)
    try:
        s3_client.delete_object(Bucket=bucket_name, Key=raw_key)  # Use s3_client here
        print(f"Deleted {raw_key} from {bucket_name}")
    except Exception as e:
        print(f"Error deleting {raw_key}: {e}")

    print(f"Data successfully written to s3://{bucket_name}/{processed_key}")