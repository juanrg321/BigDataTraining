import os
import psycopg2
import boto3
import logging
import csv
from datetime import datetime
from io import StringIO

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize the S3 client
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # PostgreSQL connection details
    pg_host = 'ec2-18-132-73-146.eu-west-2.compute.amazonaws.com'
    pg_port = '5432'
    pg_user = 'consultants'
    pg_password = 'WelcomeItc@2022'  # Regular password, no encoding needed
    pg_dbname = 'testdb'
    
    # S3 bucket details
    s3_bucket = 'myvehiclesalesproject'
    s3_key = 'rawbronze/toprocess/data.csv'
    
    try:
        # Connect to PostgreSQL
        conn = psycopg2.connect(
            host=pg_host,
            port=pg_port,
            user=pg_user,
            password=pg_password,
            dbname=pg_dbname
        )
        logger.info("Connected to PostgreSQL")

        # Create a cursor object to execute SQL queries
        cursor = conn.cursor()

        # Step 1: Get the max created_at from timestamp_table
        cursor.execute("SELECT MAX(created_at) FROM timestamp_table")
        max_timestamp_table_value = cursor.fetchone()[0]
        logger.info(f"Max created_at from timestamp_table: {max_timestamp_table_value}")

        # Step 2: Get the max created_at from vehicle_sales
        cursor.execute("SELECT MAX(created_at) FROM vehicle_sales")
        max_vehicle_sales_value = cursor.fetchone()[0]
        logger.info(f"Max created_at from vehicle_sales: {max_vehicle_sales_value}")
        
        # Step 3: Fetch records from vehicle_sales that have a created_at greater than max_timestamp_table_value
        query = """
            SELECT * 
            FROM vehicle_sales
            WHERE created_at > %s
        """
        cursor.execute(query, (max_timestamp_table_value,))
        records = cursor.fetchall()

        # Get the column names
        col_names = [desc[0] for desc in cursor.description]

        # Convert result into CSV format for S3 upload
        csv_buffer = StringIO()
        csv_writer = csv.writer(csv_buffer)
        
        # Write the column headers
        csv_writer.writerow(col_names)
        
        # Write all rows
        csv_writer.writerows(records)

        # Write the CSV data to the S3 bucket
        s3_client.put_object(Bucket=s3_bucket, Key=s3_key, Body=csv_buffer.getvalue())
        logger.info(f"Data written to S3 bucket {s3_bucket} with key {s3_key}")
        
        # Step 4: Update the timestamp_table with the new max created_at from vehicle_sales
        if max_vehicle_sales_value > max_timestamp_table_value:
            insert_query = """
            INSERT INTO timestamp_table (created_at)
            VALUES (%s)
            """

# Execute the query with only one value, `max_created_at`
            cursor.execute(insert_query, (max_vehicle_sales_value,))
            conn.commit()
            logger.info(f"Updated timestamp_table with new max created_at: {max_vehicle_sales_value}")
    
    except psycopg2.OperationalError as e:
        logger.error(f"Error connecting to PostgreSQL: {e}")
        raise e

    finally:
        # Close the connection
        if conn:
            cursor.close()
            conn.close()
            logger.info("PostgreSQL connection closed")