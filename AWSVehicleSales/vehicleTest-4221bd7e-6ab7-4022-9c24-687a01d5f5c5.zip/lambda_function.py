import json
import pandas as pd
import numpy as np
import uuid
import boto3
import os
import io
from io import StringIO

s3_client = boto3.client('s3')

def check_parquet_file(bucket_name, key):
    response = s3_client.get_object(Bucket=bucket_name, Key=key)

    body = response['Body'].read()

    # Read the Parquet file
    df = pd.read_parquet(io.BytesIO(body))

    # Check for duplicates
    duplicates = df.duplicated().sum()
    
    # Check for nulls
    nulls = df.isnull().sum()
    
    # Check for negative values in numeric columns
    negative_values = (df.select_dtypes(include=['float64', 'int64']) < 0).sum().sum()

    return duplicates, nulls.to_dict(), negative_values


def lambda_handler(event, context):
    bucket = 'myvehiclesalesproject'
    prefix = 'stagingsilver/toprocess'

    # List objects in the specified S3 directory
    objects = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
    
    total_duplicates = 0
    total_nulls = {}
    total_negative_values = 0
    
    if 'Contents' in objects:
        for obj in objects['Contents']:
            key = obj['Key']
            if key.endswith('.parquet'):
                #print(f'Processing file: {key}')
                duplicates, nulls_dict, negative_values = check_parquet_file(bucket, key)
                
                # Accumulate totals
                total_duplicates += duplicates
                total_negative_values += negative_values
                
                for col, count in nulls_dict.items():
                    if col in total_nulls:
                        total_nulls[col] += count
                    else:
                        total_nulls[col] = count
    
    total_nulls_sum = sum(total_nulls.values())

    # Total count of all issues
    total_issues = total_duplicates + total_negative_values + total_nulls_sum

    # Print the total results
    print(f'Total Duplicates: {total_duplicates}')
    print(f'Total Nulls: {total_nulls}')
    print(f'Total Negative Values: {total_negative_values}')

    # Return status code based on the total issues
    if total_issues == 0:
        return {
            'statusCode': 200,
            'body': 'No issues found.'
        }
    else:
        return {
            'statusCode': 400,
            'body': f'Found issues: Duplicates={total_duplicates}, Nulls={total_nulls_sum}, Negative Values={total_negative_values}'
        }
