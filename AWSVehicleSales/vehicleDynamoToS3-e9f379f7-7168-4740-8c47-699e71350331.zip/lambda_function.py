import json
import boto3
import os
import io
import pandas as pd

# Initialize clients
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')

# Environment variables
DYNAMODB_TABLE_NAME = 'vehicleStateTemps'
S3_BUCKET_NAME = 'myvehiclesalesproject'
S3_PREFIX = 'curatedgold/dim_temp/'

def write_to_s3(df, bucket_name, key):
    # Use a buffer to hold the CSV data
    parquet_buffer = io.BytesIO()
    df.to_parquet(parquet_buffer, index=False)  # Write DataFrame to CSV format

    # Upload CSV data to S3
    s3_client.put_object(Bucket=bucket_name, Key=key, Body=parquet_buffer.getvalue())

def lambda_handler(event, context):
    # Get the DynamoDB table
    table = dynamodb.Table(DYNAMODB_TABLE_NAME)
    
    # Scan the table to get all items
    response = table.scan()
    items = response['Items']
    
    # If there's more data, continue to scan
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        items.extend(response['Items'])
    
    # Convert items to DataFrame
    df = pd.DataFrame(items)
    
    # Construct the S3 key for the output file
    s3_key = f'{S3_PREFIX}dim_temp.parquet'
    
    # Write the DataFrame to S3 as CSV
    write_to_s3(df, S3_BUCKET_NAME, s3_key)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Data written to S3 as Parquet successfully!')
    }
