import json
import boto3

# Initialize the Kinesis client
kinesis_client = boto3.client('kinesis')

# Replace with your Kinesis stream name
KINESIS_STREAM_NAME = 'avg_state_temps1'

def calculate_average_data():
    # Example average temperatures and rainfall for each state (replace with real data as needed)
    average_data = {
        'AL': {'temperature': 70, 'rainfall': 56},  # Alabama
        'AK': {'temperature': 30, 'rainfall': 15},  # Alaska
        'AZ': {'temperature': 80, 'rainfall': 9},   # Arizona
        'AR': {'temperature': 65, 'rainfall': 50},  # Arkansas
        'CA': {'temperature': 75, 'rainfall': 22},  # California
        'CO': {'temperature': 55, 'rainfall': 15},  # Colorado
        'CT': {'temperature': 60, 'rainfall': 44},  # Connecticut
        'DE': {'temperature': 68, 'rainfall': 46},  # Delaware
        'FL': {'temperature': 78, 'rainfall': 54},  # Florida
        'GA': {'temperature': 72, 'rainfall': 50},  # Georgia
        'HI': {'temperature': 80, 'rainfall': 63},  # Hawaii
        'ID': {'temperature': 50, 'rainfall': 12},  # Idaho
        'IL': {'temperature': 55, 'rainfall': 39},  # Illinois
        'IN': {'temperature': 60, 'rainfall': 36},  # Indiana
        'IA': {'temperature': 52, 'rainfall': 34},  # Iowa
        'KS': {'temperature': 65, 'rainfall': 33},  # Kansas
        'KY': {'temperature': 65, 'rainfall': 46},  # Kentucky
        'LA': {'temperature': 75, 'rainfall': 60},  # Louisiana
        'ME': {'temperature': 45, 'rainfall': 44},  # Maine
        'MD': {'temperature': 62, 'rainfall': 40},  # Maryland
        'MA': {'temperature': 58, 'rainfall': 44},  # Massachusetts
        'MI': {'temperature': 50, 'rainfall': 33},  # Michigan
        'MN': {'temperature': 48, 'rainfall': 28},  # Minnesota
        'MS': {'temperature': 72, 'rainfall': 55},  # Mississippi
        'MO': {'temperature': 60, 'rainfall': 39},  # Missouri
        'MT': {'temperature': 50, 'rainfall': 15},  # Montana
        'NE': {'temperature': 55, 'rainfall': 30},  # Nebraska
        'NV': {'temperature': 70, 'rainfall': 9},   # Nevada
        'NH': {'temperature': 55, 'rainfall': 48},  # New Hampshire
        'NJ': {'temperature': 63, 'rainfall': 43},  # New Jersey
        'NM': {'temperature': 75, 'rainfall': 13},  # New Mexico
        'NY': {'temperature': 58, 'rainfall': 42},  # New York
        'NC': {'temperature': 68, 'rainfall': 50},  # North Carolina
        'ND': {'temperature': 45, 'rainfall': 17},  # North Dakota
        'OH': {'temperature': 60, 'rainfall': 38},  # Ohio
        'OK': {'temperature': 65, 'rainfall': 36},  # Oklahoma
        'OR': {'temperature': 60, 'rainfall': 45},  # Oregon
        'PA': {'temperature': 58, 'rainfall': 39},  # Pennsylvania
        'RI': {'temperature': 60, 'rainfall': 43},  # Rhode Island
        'SC': {'temperature': 70, 'rainfall': 50},  # South Carolina
        'SD': {'temperature': 50, 'rainfall': 20},  # South Dakota
        'TN': {'temperature': 68, 'rainfall': 54},  # Tennessee
        'TX': {'temperature': 80, 'rainfall': 29},  # Texas
        'UT': {'temperature': 60, 'rainfall': 12},  # Utah
        'VT': {'temperature': 50, 'rainfall': 39},  # Vermont
        'VA': {'temperature': 65, 'rainfall': 40},  # Virginia
        'WA': {'temperature': 60, 'rainfall': 37},  # Washington
        'WV': {'temperature': 58, 'rainfall': 45},  # West Virginia
        'WI': {'temperature': 52, 'rainfall': 32},  # Wisconsin
        'WY': {'temperature': 45, 'rainfall': 13}    # Wyoming
    }
    
    return average_data

def lambda_handler(event, context):
    # Calculate average temperatures and rainfall
    avg_data = calculate_average_data()
    
    # Prepare the message
    for state, data in avg_data.items():
        message = {
            'state': state,
            'average_temperature': data['temperature'],
            'average_rainfall': data['rainfall']
        }
        
        # Publish the message to the Kinesis stream
        response = kinesis_client.put_record(
            StreamName=KINESIS_STREAM_NAME,
            Data=json.dumps(message),
            PartitionKey=state  # Use state as the partition key
        )
        
        print(f"Sent record to Kinesis: {message}, Sequence Number: {response['SequenceNumber']}")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Messages sent to Kinesis stream successfully!')
    }
